<?php 
    include"connection.php";
    session_start();
    if(isset($_SESSION['Name'])){
      $check="SELECT * FROM customer where cus_id='".$_SESSION['Id']."'"; 
      $checkResult = mysqli_query($conn, $check);  
      if (mysqli_num_rows($checkResult) < 1) {
        header('location:cus_backend/destruction.php');
      } 
    }
    if (isset($_SESSION['msg'])) {
        echo "<script>alert('".$_SESSION['msg']."')</script>";
        unset($_SESSION['msg']);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>ZayNah</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="ZayNah is a webStore which provides variety of modest clothing with reasonable price 
    and high quality fabric.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel='stylesheet' href='style.css'>
    <link rel="shortcut icon" href="Front-end/Element/Z-logo.png" type="image/x-icon" />
</head>

<body>
    <div id="baar">
        <img class="logo" src="images/Z-logo.png" alt="ZayNah">

        <div id="bh">
            <h1>ZayNah</h1>
        </div>

        <nav id="d1">
            <ul class="sidebar">
                <li onclick=hideSidebar() id="menu"><i class='bx bx-x' style="color: white;"></i>Menu</li>
                <li><i class=' bx bx-search-alt-2'></i><input type="search" placeholder="Search Here"> </li>
                <a href="index.php">
                    <li>HOME</li>
                </a>
                <?php 
                $cat = "SELECT * FROM category";
                $newcat = mysqli_query($conn, $cat);
                if (mysqli_num_rows($newcat) > 0) {
                    while ($row = mysqli_fetch_assoc($newcat)){
                        $menu_it=strtoupper($row['Name']);
                        echo"<a href='Category.php?id={$row['Cat_id']}'>
                            <li>$menu_it</li></a>";
                    }
                } 
    
         echo"   </ul>

            <div class='ic'>
                <a class='ef hv' onclick=showCart()><i class='bx bxs-cart '></i></a>
                <a class='ef hv' onclick=showLogin()><i class='bx bx-user '></i></a>";
            if(isset($_SESSION['Name'])){
                echo"<a class='ef hv' onclick=showEdit()><i class='bx bxs-edit'></i></a>";
            }
             echo"   <a class='ef' onclick=showSidebar()><i class='bx bx-menu'></i></a>
            </div>
        </nav>
    </div>


    <div id='cart' class='popup'>
        <div class='top'>
            <img class='logo' src='images/Z-logo.png' alt='ZayNah'>
            <h1>Cart</h1>
            <i onclick=hideCart() class='closeCart bx bxs-x-circle'></i>
        </div>
        <div class='contain in'>";
       
        if(isset($_SESSION['cart'])){
            $mysql = "SELECT Name, c.pro_id, p.pro_picture, p.Pro_price, c.product_quantity FROM cart_product as c join product as p ON p.product_id = c.pro_id where c.cart_id ='".$_SESSION['cart']."'";
            $newresult = mysqli_query($conn, $mysql);

            $get_total="SELECT SUM(p.Pro_price*c.product_quantity) as to_count FROM product as p join cart_product as c ON p.product_id = c.pro_id where c.cart_id ='".$_SESSION['cart']."'";
            $newTotal = mysqli_query($conn, $get_total);
            $total = mysqli_fetch_assoc($newTotal);

            if (mysqli_num_rows($newresult) > 0) {
                echo " <table class='c_item'>
                            <tr>
                                <th>Product</th>
                                <th></th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th> </th>
                            </tr>";
                while ($row = mysqli_fetch_assoc($newresult)) {
                    echo "
                    <form method='POST' action='cus_backend/removeCartItem.php'>
                    <tr> 
                        <input hidden type='text' name='id' value={$row['pro_id']}>
                        <td><img src='images/{$row['pro_picture']}' alt='{$row['pro_picture']}' style='width:30px; height:30px;'></td>
                        <td>{$row['Name']}</td>
                        <td>{$row['product_quantity']}</td>
                        <td>{$row['Pro_price']}</td> 
                        <td><button type=submit>remove</button></td>
                    </tr>
                    </form>";
                }
                echo "</table>
                <h5>No. of Products :".mysqli_num_rows($newresult)."</h5>
                <h5>Total Amount:{$total['to_count']}</h5>
                <form class='form-group' method='POST' action=placeOrder.php>
                <input hidden type='text' name='Amount' value='{$total['to_count']}'>
                <input hidden type='text' name='Quantity' value='".mysqli_num_rows($newresult)."'>
                <button class='btn btn-dark cf'>CHECKOUT</button>
                </form>";

            } else {
                echo "<p>Your Cart is Empty</p>";
            }
        }else {
            echo "<p>You are not Registered yet</p>";
        }   
            
       echo "</div>
    </div>
    <div id='user-login' class='popup'>";

      
    if(isset($_SESSION['Name'])){
        echo "<div class='top'>
            <img class='logo' src='images/Z-logo.png' alt='ZayNah'>
            <h1>User Information</h1>
            <i onclick=hideLogin() class='closeLog bx bxs-x-circle'></i>
        </div>
        <div class='in' style='width:100%; text-align:center;'>
            <h2>Welcome ".$_SESSION['Name']."</h2>
            <a href='cus_backend/destruction.php'><button class='btn btn-dark' type='button' style='margin:5px;'>Remove Account</button></a>
        "; 
        //<!-- ---------------------------Button trigger modal---------------------------------------- -->
        echo "
            <h4 style='background-color:black; color:white;'>Order Details</h4>";
    
        $mysql ="SELECT od_id, timestamp, Od_payment, Pay_status, Od_status FROM orders WHERE cus_id=".$_SESSION['Id'];
        $newresult = mysqli_query($conn, $mysql);
    
        if (mysqli_num_rows($newresult) > 0) {
            echo "<table class='table'>
                <thead class='table-light'>
                    <tr>
                        <th scope='col'>Order id</th>
                        <th scope='col'>Time</th>
                        <th scope='col'>Amount</th>
                        <th scope='col'>Order Status</th>
                        <th scope='col'>Payment</th>
                        <th scope='col'> </th>
                        <th scope='col'> </th>
                    </tr>
                </thead>
                <tbody>";
            while ($row = mysqli_fetch_assoc($newresult)) {
                echo "<tr> 
                    <input hidden type='text' name='id' value={$row['od_id']}>     
                    <td scope='row'>{$row['od_id']}</td>
                    <td scope='col'>{$row['timestamp']}</td>
                    <td scope='col'>Rs.{$row['Od_payment']}</td>
                    <td scope='col'>{$row['Od_status']}</td>
                    <td scope='col'>{$row['Pay_status']}";
                if($row['Pay_status']=='Not Paid'){
                    echo "
                    <form method='POST' action='addPayment.php'>
                        <input type='text' value='{$row['od_id']}' name='od_id' hidden>
                        <button type='submit' style='width:100%;'>Pay</button>
                    </form></td>";
                }
                if($row['Od_status']=='Completed'){
                    $pros="SELECT * FROM order_product WHERE od_id={$row['od_id']}";
                    $pro= mysqli_query($conn,$pros);
                    echo "<td>";
                    while($pr=mysqli_fetch_assoc($pro)){
                        $p=mysqli_fetch_assoc(mysqli_query($conn,"SELECT Name ,Pro_price FROM product WHERE product_id = {$pr['pro_id']}"));
                        echo "{$p['Name']} : Rs.{$p['Pro_price']} 
                             <form method='POST' action='Reviews.php'>
                            <input type='text' value='{$pr['pro_id']}' name='pro_id' hidden>
                            <input type='text' value='{$_SESSION['Id']}' name='cus_id' hidden>
                            <input type='text' value='{$row['od_id']}' name='od_id' hidden>
                            <button type='submit' style='width:100%;'>Review</button>
                        </form>";
                    }
                    echo "</td>";
                } else if($row['Od_status']=='Pending' && $row['Pay_status']!='Paid' ){
                    echo "
                    <form method='POST' action='cus_backend/cancelOrder.php'>
                        <input type='text' value='{$row['od_id']}' name='od_id' hidden>
                        <td><button type='submit' style='width:100%;'>Cancel</button></td>
                    </form>";
                }
            }
            echo "</tbody>
            </table>";
        
    
} else {
    echo "<p>No Orders placed yet.</p>";
}
        echo "</div>
        ";
        }else{
           echo "
            <div class='top'>
            <img class='logo' src='images/Z-logo.png' alt='ZayNah'>
            <h1>Register</h1>
            <i onclick=hideLogin() class='closeLog bx bxs-x-circle'></i>
        </div>
        <form class='contain in' action='cus_backend/addCustomer.php' method='POST'>
            <div class='fl_in'>
                <label for='name'>Name :</label>
                <input type='text' name='name' pattern='[A-Z a-z]+' title='Only Alphabets are allowed.' id='name' placeholder='your name' required>
            </div>
            <div class='fl_in'>
                <label for='address'>Address :</label>
                <div class='row g-3'>
            <div class='col-sm-7'>
                <input type='text' class='form-control' placeholder='Address' aria-label='City' name='det' required>
            </div>
            <div class='col-sm'>
                <input type='text' class='form-control' placeholder='Province' aria-label='State' pattern='[A-Za-z]+' title='Only Alphabets are allowed.' name='Province' required>
            </div>
            <div class='col-sm'>
                <input type='text' class='form-control' placeholder='District' aria-label='Zip' pattern='[A-Za-z]+' title='Only Alphabets are allowed.' name='Dist' required>
            </div>
            </div>
            </div>
            <div class='fl_in'>
                <label for='Phone'>Contact No :</label>
                <input type='tel' id='Phone' name='phone1' placeholder='03xxxxxxxxx' required pattern='03[0-9]{2}[0-9]{7}' title='Phone number is not valid spaces are not allowed'>
                <input type='tel' id='Phone' name='phone2' placeholder='Phone#2' optional pattern='03[0-9]{2}[0-9]{7}' title='Phone number is not valid'>
            </div> 
            <button>Submit</button>
        </form>";
        }
    echo"</div>";
    if(isset($_SESSION['Id'])){
    $sqed ="SELECT cus_name, District, Province, Ad_details FROM customer where  cus_id='".$_SESSION['Id']."'";
    $edit = mysqli_query($conn, $sqed);
    $details=mysqli_fetch_assoc($edit);

    $phone ="SELECT phone_no FROM cus_phone where  cus_id='".$_SESSION['Id']."'";
    $row = mysqli_query($conn, $phone);
    if(mysqli_num_rows($row)>1){
        $ph1=mysqli_fetch_assoc($row);
        $ph2=mysqli_fetch_assoc($row);
    }else{
    $ph1=mysqli_fetch_assoc($row);
    }
    echo"<div id='user-edit' class='popup' style='display:none;'>
        <div class='top'>
            <img class='logo' src='images/Z-logo.png' alt='ZayNah'>
            <h1>Edit User Profile</h1>
            <i onclick=hideEdit() class='closeEdit bx bxs-x-circle'></i>
        </div>
        <form class='contain in' action='cus_backend/updateProfile.php' method='POST'>
            <div class='fl_in'>
                <label for='name'>Name :</label>
                <input type='text' name='name' value='{$details['cus_name']}' pattern='[A-Z a-z]+' title='Only Alphabets are allowed.' id='name' placeholder='your name' required>
            </div>
            <div class='fl_in'>
                <label for='address'>Address :</label>
                <div class='row g-3'>
            <div class='col-sm-7'>
                <input type='text' class='form-control' value='{$details['Ad_details']}' placeholder='Address' aria-label='City' name='det' required>
            </div>
            <div class='col-sm'>
                <input type='text' class='form-control' value='{$details['Province']}' aria-label='State' pattern='[A-Za-z]+' title='Only Alphabets are allowed.' name='Province' required>
            </div>
            <div class='col-sm'>
                <input type='text' class='form-control' value='{$details['District']}' aria-label='Zip' pattern='[A-Za-z]+' title='Only Alphabets are allowed.' name='Dist' required>
            </div>
            </div>
            </div>
            <div class='fl_in'>
                <label for='Phone'>Contact No :</label>
                <input type='tel' id='Phone' value='{$ph1['phone_no']}' name='phone1' placeholder='03xxxxxxxxx' required pattern='03[0-9]{2}[0-9]{7}' title='Phone number is not valid spaces are not allowed'>
                <input type='tel' id='Phone' value='{$ph2['phone_no']}' name='phone2' placeholder='Phone#2' optional pattern='03[0-9]{2}[0-9]{7}' title='Phone number is not valid'>
            </div> 
            <button>Save changes</button>
        </form>
        </div>";}
?>
    <script>
        function showSidebar() {
            const sidebar = document.querySelector('.sidebar')
            sidebar.style.display = 'flex';
        }
        function hideSidebar() {
            const sidebar = document.querySelector('.sidebar')
            sidebar.style.display = 'none';
        }
        function showEdit() {
            const edit = document.querySelector('#user-edit')
            edit.style.display = 'flex';
            const close = document.querySelector('.closeEdit')
            close.style.visibility = 'visible';
        }
        function hideEdit() {
            const edit = document.querySelector('#user-edit')
            edit.style.display = 'none';
            const close = document.querySelector('.closeEdit')
            close.style.visibility = 'hidden';
        }
        function showLogin() {
            const login = document.querySelector('#user-login')
            login.style.display = 'flex';
            const close = document.querySelector('.closeLog')
            close.style.visibility = 'visible';
        }
        function hideLogin() {
            const login = document.querySelector('#user-login')
            login.style.display = 'none';
            const close = document.querySelector('.closeLog')
            close.style.visibility = 'hidden';
        }
        function showCart() {
            const cart = document.querySelector('#cart')
            cart.style.display = 'flex';
            const close = document.querySelector('.closeCart')
            close.style.visibility = 'visible';
        }
        function hideCart() {
            const cart = document.querySelector('#cart')
            cart.style.display = 'none';
            const close = document.querySelector('.closeCart')
            close.style.visibility = 'hidden';
        }
    </script>
</body>

</html>