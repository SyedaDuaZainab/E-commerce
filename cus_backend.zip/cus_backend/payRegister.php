<?php
    include"../connection.php";
    session_start();
    if(isset($_POST)){

        $order=$_POST['orderId'];
        $payment=$_POST['amount'];
        $pay_method=$_POST['paymentMethod'];
        $account=$_POST['accountNumber'];

        $sql = "INSERT INTO payment(Pay_Amount,	Method,	cus_id,	od_id,	account)
        VALUES ('$payment', '$pay_method', '".$_SESSION['Id']."', '$order', '$account')";
        $result = mysqli_query($conn, $sql);

        $od_id = mysqli_insert_id($conn);

        if($result){
            $sql = "UPDATE orders
            SET Pay_status ='Paid' WHERE od_id ='$order'";
            $result = mysqli_query($conn, $sql);

            $_SESSION['msg'] = 'Your payment has been registered';
            header('location: ../index.php');
        }else{
            $_SESSION['msg'] = 'Payment cannot be registered';
            header('location: ../index.php');
        }
    }
?>