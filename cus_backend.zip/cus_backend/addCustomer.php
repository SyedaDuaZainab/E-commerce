<?php
include"../connection.php";
if($_SERVER['REQUEST_METHOD']=='POST'){
    $Name=$_POST['name'];
    $p1= $_POST['phone1'];
    $p2= $_POST['phone2'];
    $adres=$_POST['det'];
    $province=$_POST['Province'];
    $dist=$_POST['Dist'];

    $sql = "INSERT INTO customer(cus_name, Province , District, Ad_details)
            VALUES ('$Name', '$province', '$dist', '$adres')";
    $result = mysqli_query($conn, $sql);

    $cus_id = mysqli_insert_id($conn);

    $sql_ph = "INSERT INTO cus_phone(cus_id , phone_no, ph_Type)
            VALUES ('$cus_id', '$p1','Primary')"; 
    $result_ph = mysqli_query($conn, $sql_ph);
    if (!empty($p2)) {
        $sql_ph = "INSERT INTO cus_phone(cus_id , phone_no, ph_Type)
        VALUES ('$cus_id', '$p2','Secondary')"; 
        $result_ph = mysqli_query($conn, $sql_ph);
    }

    $sql_cart = "INSERT INTO cart(cus_id , No_of_products, Amount)
    VALUES('$cus_id',0,00)";
    $result_cart = mysqli_query($conn, $sql_cart);
    $cart_id = mysqli_insert_id($conn);
    if ($result && $result_ph && $result_cart) {
        $_SESSION['msg'] = '🌟You have been successfully registered🌟';
        header('location: ../index.php');
        echo "customer added SUCCESSFULLY";
    } else {
        echo "customer not added";
    }
    session_start();
    $_SESSION['Name']=$Name;
    $_SESSION['Id']=$cus_id ;
    $_SESSION['cart']=$cart_id ;
}
?>