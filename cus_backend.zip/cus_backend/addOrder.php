<?php
    include"../connection.php";
    session_start();
    if(isset($_POST)){

        $payment=$_POST['pay'];
        $pay_status=$_POST['pStatus'];
        if($pay_status=='Cash on Delivery'){
            $status='Cash on Delivery';
            $ods='Pending';
        }else{
            $status='Not Paid';
            $ods='Pending';
        }
        $sql = "INSERT INTO orders(Od_payment,	Od_status,	Pay_status,	cus_id)
        VALUES ('$payment', '$ods', '$status', '".$_SESSION['Id']."')";
        $result = mysqli_query($conn, $sql);

        $od_id = mysqli_insert_id($conn);

        if($result){
            $query="SELECT pro_id, product_quantity  from cart_product as c WHERE cart_id ='".$_SESSION['cart']."'";
            $run_query = mysqli_query($conn, $query);
            while ($product = mysqli_fetch_assoc($run_query)){
                $insert = "INSERT INTO order_product(od_id, product_quantity ,	pro_id)
                VALUES ('$od_id', '{$product['product_quantity']}', '{$product['pro_id']}')";
                $result1 = mysqli_query($conn, $insert);
            }
            $reset_cart ="DELETE from cart_product WHERE cart_id ='".$_SESSION['cart']."'";
             mysqli_query($conn, $reset_cart);
             if($pay_status!='Cash on Delivery'){
                $_SESSION['msg'] = 'Please add Payment';
                $_SESSION['order']=$od_id;
                header('location: ../addPayment.php');
             }else{
                $_SESSION['msg'] = 'Your Order has been placed';
            header('location: ../index.php');
             }

        }else{
            $_SESSION['msg'] = 'Order cannot be placed';
            header('location: ../index.php');
        }
    }
?>