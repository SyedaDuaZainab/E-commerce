<?php
session_start();
session_unset();
session_destroy();
$_SESSION['msg'] = ('Your account information is removed');
header('location:../index.php');
?>