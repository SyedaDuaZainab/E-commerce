<?php
    include"../connection.php";
    session_start();
    if(isset($_POST)){
        $order=$_POST['od_id'];
        $detail=$_POST['desc'];
        $product=$_POST['pro_id'];
        $cus=$_POST['cus_id'];
        $rating=$_POST['rating'];
        $sql = "INSERT INTO reviews(feedback, pro_id, cus_id, Rating_star)
        VALUES ( '$detail', '$product', '$cus', $rating)";
        $result = mysqli_query($conn, $sql);

        $od_id = mysqli_insert_id($conn);

        if($result){
            $sql=mysqli_query($conn,"UPDATE orders SET Od_status='Reviewed' where od_id=$order");
            echo("Review added");
            $_SESSION['msg'] = 'Review is added';
            header('location: ../index.php');
        }else{
            echo("Review not added");
        }
    }
?>