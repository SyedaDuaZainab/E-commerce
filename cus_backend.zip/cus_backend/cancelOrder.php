<?php
include"../connection.php";
session_start();
    if($_SERVER['REQUEST_METHOD']=='POST'){
        $status='Cancelled';
        $id=$_POST['id'];

        $sql = "UPDATE orders
        SET Od_status ='$status' WHERE od_id ='$id'";
        $result = mysqli_query($conn, $sql);
    if ($result) {
        $_SESSION['msg'] = ('Your order has been successfully cancelled');
        header('location:../index.php');
    } else {
        echo "Data not updated";
    }
}
?>