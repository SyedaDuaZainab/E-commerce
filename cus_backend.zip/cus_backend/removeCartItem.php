<?php
include"../connection.php";
session_start();
if($_SERVER['REQUEST_METHOD']=='POST'){
        $id=$_POST['id'];
        $sql_valid= "SELECT * from cart_product where cart_id='".$_SESSION['cart']."' AND pro_id='$id'";
        $validation = mysqli_query($conn, $sql_valid);
        $newValid = mysqli_fetch_assoc($validation);
        if ($newValid['product_quantity']>1){
            $cur_no = $newValid['product_quantity'];
            $new_no = $cur_no - 1;
            $sql_update = "UPDATE cart_product SET product_quantity='$new_no' WHERE cart_id='".$_SESSION['cart']."' AND pro_id='$id'";
            $resultA= mysqli_query($conn, $sql_update);
        }else{
       $sql = "DELETE FROM cart_product where cart_id='".$_SESSION['cart']."' && pro_id='$id'";
        $result = mysqli_query($conn, $sql);
        }
        if ($resultA) {
            $_SESSION['msg'] = 'Item Quantity reduced';
            header('location: ../index.php');
        } else if($result){
            $_SESSION['msg'] = 'Item Deleted from cart';
            header('location: ../index.php');
        }
}

?>