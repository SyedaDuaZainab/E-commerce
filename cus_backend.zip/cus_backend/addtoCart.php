<?php
include"../connection.php";
session_start();
if(isset($_SESSION['Name'])){
    if($_SERVER['REQUEST_METHOD']=='POST'){
        $id=$_POST['pro_id'];

        $redirect = "SELECT cat_id FROM product WHERE product_id='$id'";
        $reValidate = mysqli_query($conn, $redirect);
        $fetch = mysqli_fetch_assoc($reValidate);
        
        $sql_valid= "SELECT * from cart_product where cart_id='".$_SESSION['cart']."' && pro_id='$id'";
        $validation = mysqli_query($conn, $sql_valid);

        $newValid = mysqli_fetch_assoc($validation);
        if (mysqli_num_rows($validation) > 0){
            $cur_no = $newValid['product_quantity'];
            $new_no = $cur_no + 1;
            $sql_update = "UPDATE cart_product SET product_quantity='$new_no' WHERE cart_id='".$_SESSION['cart']."' && pro_id='$id'";
            $result= mysqli_query($conn, $sql_update);
        }else{
       $sql = "INSERT INTO cart_product(Cart_id, product_quantity , pro_id)
            VALUES ('".$_SESSION['cart']."','1','$id')";
        $result = mysqli_query($conn, $sql);
        }
        if ($result) {
            $_SESSION['msg'] = 'Item added to cart';
            header('location: ../Category.php?id='.$fetch['cat_id'].'');
        } else {
         echo "Data not inserted";
        }
    }
    
}else{
    $_SESSION['msg'] = 'Please Login first';
    header("Location: ../index.php");
}
?>