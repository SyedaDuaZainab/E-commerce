<?php
include"../connection.php";
if($_SERVER['REQUEST_METHOD']=='POST'){
    $Name=$_POST['name'];
    $p1= $_POST['phone1'];
    $p2= $_POST['phone2'];
    $adres=$_POST['det'];
    $province=$_POST['Province'];
    $dist=$_POST['Dist'];
    session_start();

    $cus_id = $_SESSION['Id'];
    $sql = "UPDATE customer
    SET cus_name = '$Name', Province = '$province', District= '$dist', Ad_details = '$adres' WHERE cus_id = '$cus_id'";
    $result1 = mysqli_query($conn, $sql);

    $phone = mysqli_query($conn,"SELECT phone_no from cus_phone where cus_id= '$cus_id' && ph_Type='Secondary' ");
    $sql_ph = "UPDATE cus_phone SET phone_no='$p1' where cus_id= '$cus_id' && ph_Type='Primary'"; 
    $result_ph = mysqli_query($conn, $sql_ph);
    if (!empty($p2)) {
        if(mysqli_num_rows($phone)>0){
            $sql_ph = "UPDATE cus_phone SET phone_no ='$p2' where cus_id= '$cus_id' && ph_Type='Secondary' "; 
            $result_ph2 = mysqli_query($conn, $sql_ph);
        }else{
            $sql_ph = "INSERT INTO cus_phone(cus_id , phone_no, ph_Type)
            VALUES ('$cus_id', '$p2','Secondary')"; 
            $result_ph2 = mysqli_query($conn, $sql_ph);
        }
    }

    if ($result1 && $result_ph) {
        $_SESSION['msg'] = '🌟Your profile has been successfully updated🌟';
        header('location: ../index.php');
        echo "customer added SUCCESSFULLY";
    } else {
        echo "customer not added";
    }
    $_SESSION['Name']=$Name;
}
?>